!function(){
function e(e,t,a,i,r){$(".x_label").text(e.toLowerCase()),
$(".female_male_median_ratio").text(function(){return Math.round(100*t)+"% "}),
$(".occupationgroup").text(a),$(".y_label").text(p(i)),
$(".x_label").text(p(e))}function t(e){$(".text").html(e.toLowerCase())}
function a(){b.append("g").attr("class","y axis").attr("transform","translate("+m.bottom+",0)").call(w);
x.selectAll("line.gaplines").data(s).enter().append("line").attr({x1:function(e,t){return f(t)},
x2:function(e,t){return f(t)},
y1:function(e){return v(e.y_label)},
y2:function(e){return v(e.y_label)}}).attr("opacity",1).style("stroke","#ccc").style("stroke-width",2).on("mouseover",function(a)
{d3.selectAll(".graphicitem").attr("opacity",.2),
d3.selectAll(".highlighted").classed("highlighted",!1),
d3.selectAll("."+a.x_code).classed("highlighted",!0),
t(a.x_label),
e(a.x_label,
a.female_male_median_ratio,
a.occupationgroup,
a.y_label,a.y_label)}).attr("class",function(e)
{return"gaplines graphicitem hoveritem "+e.occupationgroupshort+" "+e.x_code}),
x.selectAll("circle.maledots").data(s).enter().append("circle").attr("cx",function(e,t)
{return f(t)}).on("mouseover",function(a){d3.selectAll(".graphicitem").attr("opacity",.2),
d3.selectAll(".highlighted").classed("highlighted",!1),
d3.selectAll("."+a.x_code).classed("highlighted",!0),
t(a.x_label),e(a.x_label,
a.female_male_median_ratio,
a.occupationgroup,a.y_label,a.y_label)}).attr("fill",function(){return"#95cbee"}).attr("class",function(e)
{return"maledots graphicitem hoveritem"+e.occupationgroupshort+" "+e.x_code}).attr("r",5).attr("cy",function(e)
{return v(e.y_label)}).attr("opacity",1),x.selectAll("circle.femaledots").data(s).enter().append("circle").attr("cx",function(e,t)
{return f(t)}).on("mouseover",function(a){d3.selectAll(".graphicitem").attr("opacity",.2),d3.selectAll(".highlighted").classed("highlighted",!1),
d3.selectAll("."+a.x_code).classed("highlighted",!0),
t(a.x_label),
e(a.x_label,
a.female_male_median_ratio,
a.occupationgroup,
a.y_label,
a.y_label)}).attr("fill",function(){return"#bb2b77"}).attr("class",function(e){return"femaledots graphicitem hoveritem "+e.occupationgroupshort+" "+e.x_code}).attr("r",5).attr("cy",
function(e){return v(e.y_label)}).attr("opacity",1);
x.append("rect").attr("x",m.left).attr("y",m.top).attr("width",h).attr("height",g).attr("opacity",0).attr("class","hoverrect")}
function i(e){_.find(wageData2,function(t){e!=t.x_label.toLowerCase()?d3.selectAll("."+t.x_code).transition().duration(500).attr("opacity",.2):(d3.selectAll(".graphicitem").attr("opacity",.2),
d3.selectAll(".highlighted").classed("highlighted",!1),d3.selectAll("."+t.x_code).classed("highlighted",!0))})}
function r(t){var a=t;_.find(wageData2,function(t){if(t.x_label.toLowerCase()===a){if($("#chart-table").empty(),
e(t.x_label,t.female_male_median_ratio,t.occupationgroup,t.y_label,t.y_label),t.x_label.toLowerCase()===a)var i=t.occupationgroupshort;
var r=[];_.each(wageData2,function(e){i==e.occupationgroupshort&&(r.push(e.y_label),r.push(e.y_label))});
var n=Math.max.apply(Math,r),l=10*Math.ceil(n/1e4)+20;
$(".x-axis-title-middle").text(l/2+"K"),
$(".x-axis-title-right").text(l+"K");{var o,c,d,s,m,h,g,p;2*$("#xaxiscontainer").width()}_.each(wageData2,
function(e){if(i==e.occupationgroupshort)if(e.y_label>e.y_label){g=e.x_label,
p=(100*e.female_male_median_ratio).toFixed(1),o=e.y_label/(1e3*l)*100,c=e.y_label/(1e3*l)*100,s="mentowomen",m="men",h="women",d=(o-c)/(99-c)*100;
var t=$('<tr>    <td class="chart-label">'+g+'</td>     <td class="chart-bar-container">    	<div class="genderbarbackground" style="width:'+o+'%"></div>    	<div class="chart-box" style="padding-left:'+c+'%">    		<div class="genderdot '+m+'"></div>            <div class="genderbar '+s+'" style="width:'+d+'%;"></div>            <div class="genderdot2 '+h+'"></div>        </div>    </td>    <td class="chart-bar-label-container">        <div class="chart-percent gender-ratio">'+p+"%</div>    </td></tr>");$("#chart-table").append(t)}
else if(e.y_label<e.y_label){g=e.x_label,p=(100*e.female_male_median_ratio).toFixed(1),o=e.y_label/(1e3*l)*100,c=e.y_label/(1e3*l)*1,s="womentomen",m="women",h="men",d=(o-c)/(99-c)*100;var t=$('<tr>    <td class="chart-label">'+g+'</td>     <td class="chart-bar-container">    	<div class="genderbarbackground" style="width:'+o+'%"></div>    	<div class="chart-box" style="padding-left:'+c+'%">    		<div class="genderdot '+m+'"></div>            <div class="genderbar '+s+'" style="width:'+d+'%;"></div>            <div class="genderdot2 '+h+'"></div>        </div>    </td>    <td class="chart-bar-label-container">        <div class="chart-percent gender-ratio">'+p+"%</div>    </td></tr>");
$("#chart-table").append(t)}})}})}var n="",l=$(window).innerHeight(),o=$(window).innerWidth(),c=$("#axis-container").width(),d=($("#axis-container").height(),$(".header-text").width());o>767&&$(".header-text").css("margin-left",function(){return(o-d)/2+"px"});var s=_.sortBy(wageData2,"median_all"),m={top:10,right:10,bottom:10,left:65},h=c,g=l-50,p=($("#viz-container").width(),d3.format(",")),u=[m.left,h-m.left-m.right],f=d3.scale.linear().domain([0,422]).range(u),y=d3.scale.linear().domain(u).range([0,422]),v=d3.scale.linear().domain([0,209596]).range([g-m.top,m.bottom]),w=(d3.svg.axis().scale(f).orient("bottom"),d3.svg.axis().scale(v).tickSize(-h-m.right-10).orient("left").ticks(5).tickValues([0,5e4,1e5,15e4,2e5]).tickFormat(
function(e){return p(e)})),x=d3.select("#viz-container").append("svg").attr("width",h).attr("height",g-m.top-m.bottom).attr("class","vizContainer").append("g").attr("transform","translate("+m.left+","+m.top+")"),b=d3.select("#axis-container").append("svg").attr("class","axisContainer").attr("width",h).attr("height",g+m.top+m.bottom+10).append("g").attr("transform","translate("+m.left+","+m.top+")");a(),x.selectAll("line.zerobased").data(s).enter().append("line").attr({x1:function(e,t){return f(t)},x2:function(e,t){return f(t)},y1:function(e){return v(e.y_label)},y2:function(e){return v(e.y_label)}}).attr("class","zerobased");var A=d3.fisheye.scale(d3.scale.linear).domain([0,422]).range([m.left,h-m.left-m.right]),C=(d3.bisector(function(e,t){return t}).left,function(){$("input").blur();var a=d3.mouse(this);A.distortion(5).focus(a[0]),d3.selectAll("circle.femaledots").attr("cx",function(e,t){return A(t)}),d3.selectAll("line.gaplines").attr("x1",function(e,t){return A(t)}).attr("x2",function(e,t){return A(t)}),d3.selectAll("circle.maledots").attr("cx",
function(e,t){return A(t)}),d3.selectAll("line.gaplines").filter(function(e,t){return t==Math.round(y(a[0]))?this:null}).attr("fill",function(a){d3.selectAll(".graphicitem").attr("opacity",.2),d3.selectAll(".highlighted").classed("highlighted",!1),d3.selectAll("."+a.x_code).classed("highlighted",!0),n=a.x_label.toLowerCase(),t(a.x_label),e(a.x_label,a.female_male_median_ratio,a.occupationgroup,a.y_label,a.y_label)})});$(".header-text").hover(function(){""!=n&&$(".dropdown").dropdown("set selected",n)}),d3.selectAll("rect.hoverrect").on("mousemove",C),_.each(dataGapGraph,function(e){var t=100*e.female_male_median_ratio,a=e.x_label,i='<tr>	<td class="chart-label">'+a+'</td>    <td class="chart-bar-container" style="padding-right:0px !important">        <div class="genderbarbackground" style="width:100%"></div>        <div class="womenbar" style="width:'+t+'%"></div>        <div class="chart-box" style="padding-left:'+t+'%">            <div class="genderdot women"></div>        </div>    </td>    <td class="chart-bar-label-container">        <div class="chart-percent gender-ratio">'+t.toFixed(1)+"%</div>    </td></tr>";
$(".chart-table2").append(i)});

$(function(){socialRiser.create({text:"The pay gap between men and women among 422 major occupations, sorted by median annual earnings"});
Iframe.init()})}();